---
layout: page
title: Links 
permalink: /links/
order: 6
share: false
---

* KimLab - <https://kim-lab.org>
  * github - <https://github.com/DaehwanKimLab>
* hisat-genotype - <https://daehwankimlab.github.io/hisat-genotype>
  * github for hisat-genotype - <https://github.com/DaehwanKimLab/hisat-genotype>

* Lyda Hill Department of Bioinformatics at UT Southwestern Medical Center - <https://www.utsouthwestern.edu/departments/bioinformatics>

* Center for Computational Biology at Johns Hopkins University - <http://www.ccb.jhu.edu> 

